import java.util.Scanner;

public class Program {
    void addition(int n1, int n2){
        System.out.println("Addition of "+ n1 +" and "+n2 +" is :" +(n1 + n2));
    }

void dataValues(){
    int n1= -10; //4bytes
    char grade= 'A'; // 1 byte
    String name = "Prajwal";
    short s1 = 100; //2 bytes
    float salary = 29000.23f; //4 bytes in float values you can store upto 7 decimal values after the point
    double distance = 2.987646054756; //4 bytes in float values you can store upto 15 decimal values after the point
    boolean flag = true;

    System.out.println("Integer :" +n1);
    System.out.println("Character :" +grade);
    System.out.println("String :" +name);
    System.out.println("Short :" +s1);
    System.out.println("Float :" +salary);
    System.out.println("Double :" +distance);
    System.out.println("Boolean :" +flag);
}

void controlFlow(){
    //take input from system
    Scanner sc = new Scanner(System.in);
    String msg = "";

    while(!msg.equals("stop")){
        for(int counter=1;counter<=3;counter++){
            System.out.println("Enter your age : ");
            int age = sc.nextInt(); //next integer found in the input must be saved in age
            
            if (age<0) {
                System.out.println("Invalid age");
            }
            else if(age<18){
                System.out.println("You are not eligible for voting yet");
            }
            else{
                System.out.println("You can vote now!!!");
            }
        }
        System.out.println("Do you want to stop?");
        sc.nextLine(); // to consume remaining character in buffer
        msg=sc.nextLine();
    }

    sc.close();
}

}
