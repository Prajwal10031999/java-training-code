import studentexample.CommerceInternships;
import studentexample.EngineeringStudent;
import studentexample.Gender;
import studentexample.Student;

public class Main {
    public static void main(String[] args) {
   //     Program p1 = new Program();
    //   p1.addition(10, 20);
    //  p1.dataValues();
    //    p1.controlFlow();

    //    Factorial p2 = new Factorial();
    //    p2.findFactorial();
        

        Student s1 = new Student("Prajwal", 23, "CSE", Gender.MALE);

        System.out.println(s1.getStudentName());
        System.out.println(s1.getStudentage());
        System.out.println(s1.getStudentCourse());
        System.out.println(s1.getStudentGender());
        System.out.println(s1);

        EngineeringStudent es2 = EngineeringStudent("Prajwal", 23, "CSE", Gender.MALE);
        CommerceInternships ci1 = CommerceInternships("Prajwal", 23, "CSE", Gender.MALE);
    }
}
