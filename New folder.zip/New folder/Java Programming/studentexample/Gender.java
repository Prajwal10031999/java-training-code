package studentexample;

public enum Gender {
    MALE,
    FEMALE,
    OTHER

}
