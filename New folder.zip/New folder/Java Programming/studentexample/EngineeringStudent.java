package studentexample;

public class EngineeringStudent extends Student{
       private String studentStream;

    
    public EngineeringStudent(String studentName, int studentage, String studentCourse, Gender studentGender, String studentStream) {
        super(studentName, studentage, studentCourse, studentGender);
        this.studentStream = studentStream;
    }


    public String getStudentStream() {
        return this.studentStream;
    }

    public void setStudentStream(String studentStream) {
        this.studentStream = studentStream;
    }

    @Override
    public String toString() {
        return "{" +
            " studentStream='" + getStudentStream() + "'" +
            "}";
    }


    
}
