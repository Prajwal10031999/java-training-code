package studentexample;

public class Student {
    private String studentName;
    private int studentage;
    private String studentCourse;
    private Gender studentGender;


    public Student(String studentName, int studentage, String studentCourse, Gender studentGender) {
        this.studentName = studentName;
        this.studentage = studentage;
        this.studentCourse = studentCourse;
        this.studentGender = studentGender;
    }
    

    public String getStudentName() {
        return this.studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getStudentage() {
        return this.studentage;
    }

    public void setStudentage(int studentage) {
        this.studentage = studentage;
    }

    public String getStudentCourse() {
        return this.studentCourse;
    }

    public void setStudentCourse(String studentCourse) {
        this.studentCourse = studentCourse;
    }

    public Gender getStudentGender() {
        return this.studentGender;
    }

    public void setStudentGender(Gender studentGender) {
        this.studentGender = studentGender;
    }
    

    @Override
    public String toString() {
        return "{" +
            " studentName='" + getStudentName() + "'" +
            ", studentage='" + getStudentage() + "'" +
            ", studentCourse='" + getStudentCourse() + "'" +
            ", studentGender='" + getStudentGender() + "'" +
            "}";
    }

}
