package studentexample;

public class CommerceInternships extends Student{
        private String commerceInternshipMonth;

    public CommerceInternships(String studentName, int studentage, String studentCourse, Gender studentGender, String commerceInternshipMonth){
        
        super(studentName, studentage, studentCourse, studentGender);
        this.commerceInternshipMonth = commerceInternshipMonth;
    }

    public String getCommerceInternshipMonth() {
        return this.commerceInternshipMonth;
    }

    public void setCommerceInternshipMonth(String commerceInternshipMonth) {
        this.commerceInternshipMonth = commerceInternshipMonth;
    }


    @Override
    public String toString() {
        return "{" +
            " commerceInternshipMonth='" + getCommerceInternshipMonth() + "'" +
            "}";
    }
    




}
