package employeeexample;



public class Developer extends Employee{
    private String developerDomain;


    public Manager(String employeeId, String employeeName, float employeeSalary, int teamSize, String developerDomain) {
        super(employeeId, employeeName, employeeSalary);
        this.teamSize = teamSize;
        this.developerDomain = developerDomain;

    }



    public String getdeveloperDomain() {
        return this.developerDomain;
    }

    public void setdeveloperDomain(String developerDomain) {
        this.developerDomain = developerDomain;
    }
    

    @Override
    public String toString() {
        return "{"+ 
            " employeeId='" + getEmployeeId() + "'" +
            ", employeeName='" + getEmployeeName() + "'" +
            ", employeeSalary='" + getEmployeeSalary() + "'" + 
            ", developerDomain='" + getdeveloperDomain() + "'" +
            "}";
    }
    
    @Override
    public float calculateTax(){
        return 0.2f * this.getEmployeeSalary();
    }

    
}

