package employeeexample;

public class Manager extends Employee{
    private int teamSize;
    private String managerLocation;


    public Manager(String employeeId, String employeeName, float employeeSalary, int teamSize, String managerLocation) {
        super(employeeId, employeeName, employeeSalary);
        this.teamSize = teamSize;
        this.managerLocation = managerLocation;

    }

    public int getTeamSize() {
        return this.teamSize;
    }

    public void setTeamSize(int teamSize) {
        this.teamSize = teamSize;
    }

    public String getManagerLocation() {
        return this.managerLocation;
    }

    public void setManagerLocation(String managerLocation) {
        this.managerLocation = managerLocation;
    }
    

    @Override
    public String toString() {
        return "{"+ 
            " employeeId='" + getEmployeeId() + "'" +
            ", employeeName='" + getEmployeeName() + "'" +
            ", employeeSalary='" + getEmployeeSalary() + "'" + 
            " teamSize='" + getTeamSize() + "'" +
            ", managerLocation='" + getManagerLocation() + "'" +
            "}";
    }
    
    @Override
    public float calculateTax(){
        return 0.2f * this.getEmployeeSalary();
    }

    
}
