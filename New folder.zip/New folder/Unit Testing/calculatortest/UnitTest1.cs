namespace calculatortest;
using NUnit.Framework;
using calculator;
public class Tests
{
    CalculatorOperations obj;

    [OneTimeSetUp]
    public void Init(){
        this.obj = new CalculatorOperations();
    }
    [SetUp]
    public void Setup()
    {
        Assert.NotNull(this.obj);
    }

    [Test]
    public void TestAddition1()
    {   
        //arrange
        CalculatorOperations obj = new CalculatorOperations();

        //act
        double actualAns =Math.Round(obj.Addition(10,20),1); // call
        

        //assert
        double expectedAns = 30.0;
        Assert.That(actualAns,Is.EqualTo(expectedAns));

    }

    [Test]
            public void TestSubtraction1()
    {   
        //arrange
        CalculatorOperations obj = new CalculatorOperations();

        //act
        double actualAns = Math.Round(obj.Subtraction(10.0,20.0),1); // call
        

        //assert
        double expectedAns = -10.0;
        Assert.That(actualAns,Is.EqualTo(expectedAns));

    }

    [Test]
        public void TestMultiplication1()
    {   
        //arrange
        CalculatorOperations obj = new CalculatorOperations();

        //act
        double actualAns = Math.Round(obj.Multiplication(10.0,20.0),1); // call
        

        //assert
        double expectedAns = 200.0;
        Assert.That(actualAns,Is.EqualTo(expectedAns));

    }

    [Test]
    public void TestDivision1()
    {   
        //arrange
        CalculatorOperations obj = new CalculatorOperations();

        //act
        double ans = obj.Division(10.0,20.0); // call
        double actualAns = Math.Round(ans,1);
        

        //assert
        double expectedAns = 0.5;
        Assert.That(actualAns,Is.EqualTo(expectedAns));

    }

    [Test]
        public void TestDivision2()
    {   
        //arrange
        CalculatorOperations obj = new CalculatorOperations();

        //act
        double firstNumber =10.0;
        double secondNumber = 0.0;
        
        //Assert.Throws<DivideByZeroException>( ()=> obj.Division(firstNumber, secondNumber) );

        Exception ex = Assert.Throws<DivideByZeroException>( ()=> obj.Division(firstNumber, secondNumber) );
        Assert.That("Denominator is zero", Is.EqualTo(ex.Message));
    }
    
    [TearDown]
    public void TearDown(){
        System.Console.WriteLine($"A Test Method ends here!");
    }

    [OneTimeTearDown]
    public void OneTimeDestroy(){
        System.Console.WriteLine($"Testing Completed");
    }
}