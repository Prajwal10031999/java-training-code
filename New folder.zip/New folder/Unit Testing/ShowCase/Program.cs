﻿using calculator;
namespace Driver
{
    public class Program{
        public static void Main(string[] args)
        {
            CalculatorOperations obj = new CalculatorOperations();
            double ans = obj.Addition(10,20);
            Console.WriteLine($"{ans}");
            double ans1 = obj.Division(3,2);
            System.Console.WriteLine($"{ans1}");

        }
    }
}
