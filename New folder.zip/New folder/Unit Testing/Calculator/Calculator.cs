using System;

/*
    this class contains method providing basic arithematic operations
    Each of these take double values as parameters and return answer as double
*/
namespace calculator
{
    public class CalculatorOperations{
        //method returns sum of two numbers
        public double Addition(double firstNumber, double secondNumber){
            return firstNumber + secondNumber;

        }
        //method returns difference of two numbers
         public double Subtraction(double firstNumber, double secondNumber){
            return firstNumber - secondNumber;

        }
        //method returns product of two numbers
         public double Multiplication(double firstNumber, double secondNumber){
            return firstNumber * secondNumber;

        }
        //method returns division of two numbers
         public double Division(double firstNumber, double secondNumber){
            if(secondNumber == 0){
                throw new DivideByZeroException("Denominator is zero");
            }
            else{
                return firstNumber / secondNumber;
            }

        }
        //method returns exponent of a number raised to power of another number
         public double Exponent(double firstNumber, double secondNumber){
            return Math.Pow(firstNumber, secondNumber);

        }
    }
}