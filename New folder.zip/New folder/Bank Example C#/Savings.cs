namespace bankportal
{
    public class Savings : Account, InterestElligibleAccounts, AccountFunctionality
    {
        

        public Savings(string accountHolderName, int accountBalace, string accountNumber, string accountIfscCode, DebitCard accountDebitCard) : base(accountHolderName, accountBalace, accountNumber, accountIfscCode, accountDebitCard)
        {
            this.savingsAccountMinBalance = savingsAccountMinBalance;
            this.savingsAccountGrade = savingsAccountGrade;

        }



        protected int savingsAccountMinBalance{
            get{return savingsAccountMinBalance;}
            set{savingsAccountMinBalance = value;}
        }
        
        protected AccountGrade savingsAccountGrade{
            get{return savingsAccountGrade;}
            set{savingsAccountGrade = value;}
        }
        
 public override float chceckBalance()
        {
            Console.WriteLine($"Please enter your PIN number : ");
            int pin = Convert.ToInt32(Console.ReadLine());

            if(pin==this.accountDebitCard.getdebitCardPin()){
                return this.accountBalace;
            }
            else{
                throw new Exception($"Invalid PIN");
            }
        }
        public float calculateInterest()
        {
            return 0.05f * this.chceckBalance();
        }
    }
    
}