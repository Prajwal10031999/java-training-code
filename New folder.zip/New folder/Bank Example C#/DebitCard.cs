using System;

public class DebitCard{
        private string debitCardNumber;
        private string debitCardExpiry;
        private int debitCardCvvNumber;
        private int debitCardPin;

        private int DebitCardPin{
        //get {return debitCardPin;}
        set {debitCardPin = value;}
        get{ return debitCardPin;}

    }
        private string DebitCardNumber{
        get {return debitCardNumber;}
        set {debitCardNumber = value;}

    }
        private string DebitCardExpiry{
        get {return debitCardExpiry;}
        set {debitCardExpiry = value;}

    }
        private int DebitCardCvvNumber{
        get {return debitCardCvvNumber;}
        set {debitCardCvvNumber = value;}

    }

    public DebitCard(string debitCardNumber, int debitCardCvvNumber, string debitCardExpiry, int debitCardPin){
        this.debitCardNumber = debitCardNumber;
        this.debitCardCvvNumber = debitCardCvvNumber;
        this.debitCardExpiry = debitCardExpiry;
        this.debitCardPin = debitCardPin;

    }
    public override string ToString(){
        return $"[ Debit Card: Number {debitCardNumber}, Expiry {debitCardExpiry}, Pin {debitCardPin}, CVV {debitCardCvvNumber} ]";
    }

   



}
