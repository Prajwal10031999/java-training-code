namespace bankportal
{
    public abstract class Account : AccountFunctionality {


        private string accountHolderName;
        private int accountBalace;
        private string accountNumber;
        private string accountIfscCode;
        private DebitCard accountDebitCard;




        private string AccountHolderName{
            get {return accountHolderName;}
            set {accountHolderName = value;}
            }
        private int AccountBalace{
            get {return accountBalace;}
            set {accountBalace = value;}
            }
         private string AccountNumber{
            get {return accountNumber;}
            set {accountNumber = value;}
            }
         private string AccountIfscCode{
            get {return accountIfscCode;}
            set {accountIfscCode = value;}
            }
         private DebitCard AccountDebitCard{
            get {return accountDebitCard;}
            set {accountDebitCard = value;}
            }
        public Account(string accountHolderName, int accountBalace, string accountNumber, string accountIfscCode, DebitCard accountDebitCard){
            this.accountHolderName = accountHolderName;
            this.accountBalace = accountBalace;
            this.accountIfscCode = accountIfscCode;
            this.accountNumber = accountNumber;
            this.accountDebitCard = accountDebitCard;
        }

        public abstract float chceckBalance();
    }
}
