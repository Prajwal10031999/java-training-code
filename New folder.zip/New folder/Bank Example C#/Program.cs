﻿namespace bankportal
{
    public class Program{
        public static void Main(String[] args){
            DebitCard dc1 = new DebitCard("1234 3245 5678", 123, "00/25", 0000);
            Savings s1 = new Savings("prajwal", 50000, "asd12", "pun23",dc1);

            System.Console.WriteLine($"Account balance is: {s1.chceckBalance()})");
    }
}
}