namespace bankportal{
    public enum AccountGrade
    {
        REGULAR,
        PLATINUM
    }
}