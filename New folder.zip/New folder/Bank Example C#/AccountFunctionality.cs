namespace bankportal
{
    public interface AccountFunctionality
    {
        public float chceckBalance();
    }
}