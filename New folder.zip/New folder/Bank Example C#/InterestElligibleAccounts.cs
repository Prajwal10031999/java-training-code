namespace bankportal
{
    public interface InterestElligibleAccounts
    {
        public float calculateInterest();
    }
}