
public enum AccountGrade {
    REGULAR,
    PLATINUM

}
