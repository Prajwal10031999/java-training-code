abstract public class Account implements AccountFunctionality {
    private String accountHolderName;
    private float accountBalance;
    private String accountNumber;
    private String accountIfscCode;
    //every account has a debit card

    private DebitCard accountDebitCard;


    public Account(String accountHolderName, float accountBalance, String accountNumber, String accountIfscCode, DebitCard accountDebitCard) {
        this.accountHolderName = accountHolderName;
        this.accountBalance = accountBalance;
        this.accountNumber = accountNumber;
        this.accountIfscCode = accountIfscCode;
        this.accountDebitCard = accountDebitCard;
    }

    public Account(String accountHolderName, float accountBalance, String accountNumber, String accountIfscCode) {
        this.accountHolderName = accountHolderName;
        this.accountBalance = accountBalance;
        this.accountNumber = accountNumber;
        this.accountIfscCode = accountIfscCode;
    }

    public void setAccountDebitCard(DebitCard accountDebitCard){
        this.accountDebitCard = accountDebitCard;
    }


    public String getAccountHolderName() {
        return this.accountHolderName;
    }

    public float getAccountBalance() {
        return this.accountBalance;
    }

    public String getAccountNumber() {
        return this.accountNumber;
    }

    public String getAccountIfscCode() {
        return this.accountIfscCode;
    }

    public DebitCard getAccountDebitCard() {
        return this.accountDebitCard;
    }

    

}
