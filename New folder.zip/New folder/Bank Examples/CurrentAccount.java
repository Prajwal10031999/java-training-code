public class CurrentAccount extends Account {
    private String AffiliatedBusinessSerialNumber;

    
    
}
