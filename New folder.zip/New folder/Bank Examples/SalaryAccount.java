import java.util.Scanner;

public class SalaryAccount extends Account implements InterestEligibleAccounts{
    private int MaximumOneTimeTransaction;
    private String SalaryAssociatedCompanyName;


    //salary account with no requirement of debit card
    public SalaryAccount(String accountHolderName, float accountBalance, String accountNumber, String accountIfscCode,  int MaximumOneTimeTransaction,  String SalaryAssociatedCompanyName ){
        super(accountHolderName, accountBalance, accountNumber, accountIfscCode);
        this.MaximumOneTimeTransaction=MaximumOneTimeTransaction;
        this.SalaryAssociatedCompanyName=SalaryAssociatedCompanyName;

    }

    public SalaryAccount(String accountHolderName, float accountBalance, String accountNumber, String accountIfscCode, DebitCard accountDebitCard, int MaximumOneTimeTransaction,String SalaryAssociatedCompanyName){
        super(accountHolderName, accountBalance, accountNumber, accountIfscCode, accountDebitCard);
        this.MaximumOneTimeTransaction=MaximumOneTimeTransaction;
        this.SalaryAssociatedCompanyName=SalaryAssociatedCompanyName;

    }


    public int getMaximumOneTimeTransaction() {
        return this.MaximumOneTimeTransaction;
    }

    public String getSalaryAssociatedCompanyName() {
        return this.SalaryAssociatedCompanyName;
    }

    @Override
    public float checkBalance() throws Exception{
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your debit card PIN :");
        int pin = sc.nextInt();
        if(pin == this.getAccountDebitCard().getDebitCardPin()){
            return this.getAccountBalance()
        }
        else{
            throw new Exception("INVALID PIN")
        }
    }

    @Override
    public float calculateInterest() throws Exception{

        return 0.03f * this.checkBalance();
    }


}