public interface InterestEligibleAccounts {

    float calculateInterest() throws Exception;
    
}
