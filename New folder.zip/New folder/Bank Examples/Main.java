public class Main {
    public static void main(String[] args) {
        DebitCard dc1 = new DebitCard(123, "01/28", 101, "12344");
        SalaryAccount sa1 = new SalaryAccount("Prajwal", 50000, "3456726", "ABC123", dc1, 20000, "Siemens");
        

        System.out.println(     "Interest amount: " + sa1.calculateInterest()        );
         

        System.out.println("Balance amount: " +         sa1.checkBalance()        );
    }
    
}
