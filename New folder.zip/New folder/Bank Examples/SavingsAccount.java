public class SavingsAccount extends Account {
    private int savingsAccountMinBalance;
    private AccountGrade savingsAccountGrade;


     //salary account with no requirement of debit card
    public SavingsAccount(String accountHolderName, float accountBalance, String accountNumber, String accountIfscCode,  int savingsAccountMinBalance, AccountGrade savingsAccountGrade){
        super(accountHolderName, accountBalance, accountNumber, accountIfscCode);
        this.savingsAccountMinBalance=savingsAccountMinBalance;
        this.savingsAccountGrade=savingsAccountGrade;

    }

    public SavingsAccount(String accountHolderName, float accountBalance, String accountNumber, String accountIfscCode, DebitCard accountDebitCard, int savingsAccountMinBalance, AccountGrade savingsAccountGrade){
        super(accountHolderName, accountBalance, accountNumber, accountIfscCode, accountDebitCard);
        this.savingsAccountMinBalance=savingsAccountMinBalance;
        this.savingsAccountGrade=savingsAccountGrade;

    }



    public int getSavingsAccountMinBalance() {
        return this.savingsAccountMinBalance;
    }


    public AccountGrade getSavingsAccountGrade() {
        return this.savingsAccountGrade;
    }

    @Override
    public float checkBalance(){
        return 0;
    }

    @Override
    public float calculateInterest(){
        return 0;
    }

}
