public interface AccountFunctionality {
    float checkBalance() throws Exception;
    
}
