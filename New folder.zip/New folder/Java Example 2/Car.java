public class Car extends Vehicle {
    private cartype carTypes;
    private geartype carGearType;


    public Car(cartype carTypes, geartype carGearType, String vehicleChasisNumber, String vehicleBrand, String vehicleExShowroomPrice, String vehicleColor, fueltype vehicleFuelType) {
        super(vehicleChasisNumber, vehicleBrand, vehicleExShowroomPrice, vehicleColor, vehicleFuelType);
        this.carTypes = carTypes;
        this.carGearType = carGearType;
    }

    public cartype getCarTypes() {
        return this.carTypes;
    }

    public void setCarTypes(cartype carTypes) {
        this.carTypes = carTypes;
    }

    public geartype getCarGearType() {
        return this.carGearType;
    }

    public void setCarGearType(geartype carGearType) {
        this.carGearType = carGearType;
    }



    
}
