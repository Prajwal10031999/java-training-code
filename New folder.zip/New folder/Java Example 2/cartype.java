
public enum cartype {
    SUV,
    HATCHBACK,
    SEDAN

}
