
public enum terraintype {
    PLAIN_TERRAIN,
    MOUNTAIN_TERRAIN;

}
