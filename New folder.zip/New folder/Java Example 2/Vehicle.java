public class Vehicle{
    private String vehicleChasisNumber;
    private String vehicleBrand;
    private String vehicleExShowroomPrice;
    private String vehicleColor;
    private fueltype vehicleFuelType;


    public Vehicle(String vehicleChasisNumber, String vehicleBrand, String vehicleExShowroomPrice, String vehicleColor, fueltype vehicleFuelType) {
        this.vehicleChasisNumber = vehicleChasisNumber;
        this.vehicleBrand = vehicleBrand;
        this.vehicleExShowroomPrice = vehicleExShowroomPrice;
        this.vehicleColor = vehicleColor;
        this.vehicleFuelType = vehicleFuelType;
    }

    public String getVehicleChasisNumber() {
        return this.vehicleChasisNumber;
    }

    public void setVehicleChasisNumber(String vehicleChasisNumber) {
        this.vehicleChasisNumber = vehicleChasisNumber;
    }

    public String getVehicleBrand() {
        return this.vehicleBrand;
    }

    public void setVehicleBrand(String vehicleBrand) {
        this.vehicleBrand = vehicleBrand;
    }

    public String getVehicleExShowroomPrice() {
        return this.vehicleExShowroomPrice;
    }

    public void setVehicleExShowroomPrice(String vehicleExShowroomPrice) {
        this.vehicleExShowroomPrice = vehicleExShowroomPrice;
    }

    public String getVehicleColor() {
        return this.vehicleColor;
    }

    public void setVehicleColor(String vehicleColor) {
        this.vehicleColor = vehicleColor;
    }

    public fueltype getVehicleFuelType() {
        return this.vehicleFuelType;
    }

    public void setVehicleFuelType(fueltype vehicleFuelType) {
        this.vehicleFuelType = vehicleFuelType;
    }

    

    Vehicle[] arr = new Vehicle[100];



}