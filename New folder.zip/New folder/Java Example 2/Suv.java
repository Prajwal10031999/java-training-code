public class Suv extends Car {
    private int suvWidth;
    public Suv(cartype carTypes, geartype carGearType, String vehicleChasisNumber, String vehicleBrand,
            String vehicleExShowroomPrice, String vehicleColor, fueltype vehicleFuelType, int suvWidth) {
        super(carTypes, carGearType, vehicleChasisNumber, vehicleBrand, vehicleExShowroomPrice, vehicleColor, vehicleFuelType);
        this.suvWidth = suvWidth;
    }


    public int getSuvWidth() {
        return this.suvWidth;
    }

    public void setSuvWidth(int suvWidth) {
        this.suvWidth = suvWidth;
    }


    


    
    
}
