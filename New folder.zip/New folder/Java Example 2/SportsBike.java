public class SportsBike extends Bike {
    private terraintype sportBikeTerrainType;
    public SportsBike(String vehicleChasisNumber, String vehicleBrand, String vehicleExShowroomPrice,
            String vehicleColor, fueltype vehicleFuelType, starttype bikeStartType, terraintype sportBikeTerrainType) {
        super(vehicleChasisNumber, vehicleBrand, vehicleExShowroomPrice, vehicleColor, vehicleFuelType, bikeStartType);
        
        this.sportBikeTerrainType=sportBikeTerrainType;
    }

    public terraintype getSportBikeTerrainType() {
        return this.sportBikeTerrainType;
    }

    public void setSportBikeTerrainType(terraintype sportBikeTerrainType) {
        this.sportBikeTerrainType = sportBikeTerrainType;
    }


    
    
}
