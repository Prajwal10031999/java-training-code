public class CommuteBike extends Bike {
    private int commuteCapacity;

    public CommuteBike(String vehicleChasisNumber, String vehicleBrand, String vehicleExShowroomPrice,
            String vehicleColor, fueltype vehicleFuelType, starttype bikeStartType, int commuteCapacity) {
        super(vehicleChasisNumber, vehicleBrand, vehicleExShowroomPrice, vehicleColor, vehicleFuelType, bikeStartType);
        //TODO Auto-generated constructor stub
        this.commuteCapacity=commuteCapacity;
    }

    public int getCommuteCapacity() {
        return this.commuteCapacity;
    }

    public void setCommuteCapacity(int commuteCapacity) {
        this.commuteCapacity = commuteCapacity;
    }

   
    
}
