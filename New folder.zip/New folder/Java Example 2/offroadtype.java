
public enum offroadtype {
    MOUNTAIN,
    DESERT;

}
