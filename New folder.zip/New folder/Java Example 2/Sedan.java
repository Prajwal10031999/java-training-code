public class Sedan extends Car {
    private int sedanLength;

    public Sedan(cartype carTypes, geartype carGearType, String vehicleChasisNumber, String vehicleBrand,
            String vehicleExShowroomPrice, String vehicleColor, fueltype vehicleFuelType, int sedanLength ) {
        super(carTypes, carGearType, vehicleChasisNumber, vehicleBrand, vehicleExShowroomPrice, vehicleColor, vehicleFuelType);
        this.sedanLength=sedanLength;
    }

    public int getSedanLength() {
        return this.sedanLength;
    }

    public void setSedanLength(int sedanLength) {
        this.sedanLength = sedanLength;
    }

    
}
