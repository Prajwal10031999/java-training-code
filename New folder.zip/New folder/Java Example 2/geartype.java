
public enum geartype {
    MANUAL,
    AUTOMATIC;

}
