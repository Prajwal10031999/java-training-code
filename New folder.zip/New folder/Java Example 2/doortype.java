
public enum doortype {
    TWO_DOOR,
    FOUR_DOOR;

}
