
public enum fueltype {
    PETROL,
    DESIEL;

}
