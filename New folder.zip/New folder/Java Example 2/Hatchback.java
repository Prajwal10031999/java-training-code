public class Hatchback extends Car{
    private doortype hatchbackDoortype;
    public Hatchback(cartype carTypes, geartype carGearType, String vehicleChasisNumber, String vehicleBrand,
            String vehicleExShowroomPrice, String vehicleColor, fueltype vehicleFuelType,doortype hatchbackDoortype ) {
        super(carTypes, carGearType, vehicleChasisNumber, vehicleBrand, vehicleExShowroomPrice, vehicleColor, vehicleFuelType);
        this.hatchbackDoortype=hatchbackDoortype;
    }

    public doortype getHatchbackDoortype() {
        return this.hatchbackDoortype;
    }

    public void setHatchbackDoortype(doortype hatchbackDoortype) {
        this.hatchbackDoortype = hatchbackDoortype;
    }


    
    
}
