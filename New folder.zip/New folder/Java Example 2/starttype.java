
public enum starttype {
    KICK,
    AUTOMATIC_START;

}
