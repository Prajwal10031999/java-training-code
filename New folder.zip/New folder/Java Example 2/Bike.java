public class Bike extends Vehicle {
    private starttype bikeStartType;

    public Bike(String vehicleChasisNumber, String vehicleBrand, String vehicleExShowroomPrice, String vehicleColor,
            fueltype vehicleFuelType, starttype bikeStartType) {
        super(vehicleChasisNumber, vehicleBrand, vehicleExShowroomPrice, vehicleColor, vehicleFuelType);
        this.bikeStartType=bikeStartType;
    }

    public starttype getBikeStartType() {
        return this.bikeStartType;
    }

    public void setBikeStartType(starttype bikeStartType) {
        this.bikeStartType = bikeStartType;
    }
    
    
}
