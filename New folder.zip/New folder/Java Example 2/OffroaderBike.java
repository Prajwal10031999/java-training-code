public class OffroaderBike extends Bike {
    private offroadtype offRoadType;

    public OffroaderBike(String vehicleChasisNumber, String vehicleBrand, String vehicleExShowroomPrice,
            String vehicleColor, fueltype vehicleFuelType, starttype bikeStartType, offroadtype offRoadType) {
        super(vehicleChasisNumber, vehicleBrand, vehicleExShowroomPrice, vehicleColor, vehicleFuelType, bikeStartType);
        this.offRoadType=offRoadType;
    }

    public offroadtype getOffRoadType() {
        return this.offRoadType;
    }

    public void setOffRoadType(offroadtype offRoadType) {
        this.offRoadType = offRoadType;
    }


    
}
