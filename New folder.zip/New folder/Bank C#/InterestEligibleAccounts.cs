namespace bankportal
{
    public interface InterestEligibleAccounts
    {
        public  float calcuateInterest();
    }
}