namespace bankportal
{
    //for implementing an interface use classname : interface name syntax. No implements keyword is required
    public abstract class Account : AccountFunctionalities
    {
        private string accountHolderName;
        private float accountBalance;
        private string accountNumber;
        private string accountIfscCode;
        private DebitCard accountDebitCard;



        protected Account(string accountHolderName, float accountBalance, string accountNumber, string accountIfscCode, DebitCard accountDebitCard)
        {
            this.accountHolderName = accountHolderName;
            this.accountBalance = accountBalance;
            this.accountNumber = accountNumber;
            this.accountIfscCode = accountIfscCode;
            this.accountDebitCard = accountDebitCard;
        }

        protected string AccountHolderName{
            get{return accountHolderName;}
            set{accountHolderName = value;}
        }


        protected float AccountBalance{
            get{return accountBalance;}
            set{accountBalance = value;}
        }


        protected string AccountNumber{
            get{return accountNumber;}
            set{accountNumber = value;}
        }


        protected string AccountIfscCode{
            get{return accountIfscCode;}
            set{accountIfscCode = value;}
        }

        
        protected DebitCard AccountDebitCard{
            get{return accountDebitCard;}
            set{accountDebitCard = value;}
        }

        public abstract float checkBalance();
    }


}