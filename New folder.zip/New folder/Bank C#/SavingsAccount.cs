namespace bankportal
{
    public class SavingsAccount : Account, InterestEligibleAccounts
    {

        private int savingsAccountMinBalance;
        private AccountGrade savingsAccountGrade;

        public SavingsAccount(string accountHolderName, float accountBalance, string accountNumber, string accountIfscCode, DebitCard accountDebitCard,int savingsAccountMinBalance, AccountGrade savingsAccountGrade)
        :base (accountHolderName,accountBalance, accountNumber, accountIfscCode, accountDebitCard)
        {
            this.savingsAccountMinBalance = savingsAccountMinBalance;
            this.savingsAccountGrade = savingsAccountGrade;
        }

        public int SavingsAccountMinBalance{
            get{return savingsAccountMinBalance;}
            set{savingsAccountMinBalance = value;}
        }

        public AccountGrade SavingsAccountGrade{
            get{return savingsAccountGrade;}
            set{savingsAccountGrade = value;}
        }
        

        public float calcuateInterest()
        {
            //TO-DO later
            return 0.05f * this.checkBalance();
        }

        //use override to indicate overriding of method
        public override float checkBalance(){
            Console.WriteLine($"Please enter your PIN number: ");
            int pin = Convert.ToInt32(Console.ReadLine());

            if(pin == this.AccountDebitCard.getDebitCardPin()){
                return this.AccountBalance;
            }
            else{
                throw new Exception("Invalid PIN");
            }
            
            
        }

    }
}