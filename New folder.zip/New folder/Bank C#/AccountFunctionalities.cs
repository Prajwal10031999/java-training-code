namespace bankportal
{
    public interface AccountFunctionalities
    {
        public float checkBalance();
    }
}