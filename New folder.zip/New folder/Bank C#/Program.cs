﻿namespace bankportal
{
    public class Program
    {
        public static void Main(string[] args)
        {
            DebitCard dc1 = new DebitCard("1676 1777 7777",123,"08/25",0000);

            SavingsAccount s1 = new SavingsAccount("Prajwal",50000.0f,"Ax122323","PUN1111", dc1,
                                                     10000,AccountGrade.REGULAR);        
            Console.WriteLine($"Account balance is: {s1.checkBalance()}");
              
        }
    }
}