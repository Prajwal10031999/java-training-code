namespace bankportal
{
    public class SalaryAccount : Account, InterestEligibleAccounts
    {

        private int salaryAccountDailyWithDrawLimit;

        public SalaryAccount(string accountHolderName, float accountBalance, string accountNumber, string accountIfscCode, DebitCard accountDebitCard,int salaryAccountDailyWithDrawLimit)
        :base (accountHolderName,accountBalance, accountNumber, accountIfscCode, accountDebitCard)
        {
            this.salaryAccountDailyWithDrawLimit = salaryAccountDailyWithDrawLimit;
        }

        public int SalaryAccountDailyWithDrawLimit{
            get;
            set;
        }

        public float calcuateInterest()
        {
            //TO-DO later
            return 0.03f * this.checkBalance();
        }

        //use override to indicate overriding of method
        public override float checkBalance(){
            Console.WriteLine($"Please enter your accountNumber number: ");
            string? acNumber = Console.ReadLine();

            if(acNumber == this.AccountNumber){
                return this.AccountBalance;
            }
            else{
                throw new Exception("Invalid account number");
            }
            
            
        }

    }
}