using System;

namespace bankportal
{
    public class DebitCard
    {

        private string debitCardNumber;
        private int debitCardCvvNumber;
        private string debitCardExpiry;
        private int debitCardPin;

    


        private string DebitCardNumber{
            get {return debitCardNumber;}
            set {debitCardNumber = value;}
        }
        private int DebitCardCvvNumber{
            get {return debitCardCvvNumber;}
            set {debitCardCvvNumber = value;}
        }
        private string DebitCardExpiry{
            get {return debitCardExpiry;}
            set {debitCardExpiry = value;}
        }

        private int DebitCardPin{
            set {debitCardPin = value;}
            get{ return this.debitCardPin; } //throwing away the getter part of the property

        }

        public DebitCard(string debitCardNumber,int debitCardCvvNumber,string debitCardExpiry,int debitCardPin){
            this.debitCardNumber = debitCardNumber;
            this.debitCardExpiry = debitCardExpiry;
            this.debitCardPin = debitCardPin;
            this.debitCardCvvNumber = debitCardCvvNumber;
        }

        public override string ToString(){
            return $"[ Debit Card: Number {debitCardNumber}, Expiry {debitCardExpiry}, Pin {debitCardPin}, CVV {debitCardCvvNumber} ]";
        }

        public int getDebitCardPin(){
            return this.debitCardPin;
        }

    }
}