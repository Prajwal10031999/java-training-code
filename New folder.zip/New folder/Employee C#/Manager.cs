namespace example{
    public class Manager : Employee
    {
        private string _managerLocation;
        private int _managerTeamSize;

        public Manager(int employeeId, string employeeName, string managerLocation, int managerTeamSize)
        : base(employeeId, employeeName)
        {
            _managerLocation = managerLocation;
            _managerTeamSize = managerTeamSize;
        }

    }
}