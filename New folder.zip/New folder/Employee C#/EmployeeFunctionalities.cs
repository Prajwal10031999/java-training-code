namespace example
{
    public interface IEmployeeFunctionalities
    {
        public const string ZONE = "ASIA INDIA";
        public void checkAttendance();
        public void applyForLeave();
        public void fetchSalarySlip();
    }
}
