namespace TicketBookingApp
{
    public enum SeatType {
        SILVER,
        GOLD,
        PLATINUM
    }
}