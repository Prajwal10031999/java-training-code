namespace TicketBookingApp
{
    /*
        This class defines the basic structure of the Ticket class.
    */
    public class Ticket {

         //Unique ticket number, To distinguish between different tickets
        private string ticketNumber;
        public string TicketNumber {
            get{ return ticketNumber;}
        }

        private Movie movieSelected;

        private float ticketPrice;

        private SeatType seatType;

        private int noOfSeats;
        private string date;

        public Ticket(string ticketNumber, Movie movieSelected, float ticketPrice, SeatType seatType, int noOfSeats, string date)
        {
            this.ticketNumber = ticketNumber;
            this.movieSelected = movieSelected;
            this.ticketPrice = ticketPrice;
            this.seatType = seatType;
            this.noOfSeats = noOfSeats;
            this.date = date;
        }
        
        public override string ToString() {
            return $@"
            Ticket Number: {ticketNumber}
            Movie: {movieSelected.MovieName}
            Ticket Price: {ticketPrice}
            Seat Type: {seatType.ToString()}
            No of Seats: {noOfSeats}
            Date: {date}";
        }

        public string ToSingleString() {
            return $@"{ticketNumber,-30}{movieSelected.MovieName,-30}{ticketPrice,-10}{noOfSeats,-10}{date,-10}";
        }


    }
}