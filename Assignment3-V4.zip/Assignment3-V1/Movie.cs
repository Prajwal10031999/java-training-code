namespace TicketBookingApp
{
    /*
        This class defines the basic struture of a Movie.
    */
    public class Movie {

        //Unique movie code, To distinguish between different movies
        private string movieCode;    
        public string MovieCode {
            get {return movieCode;}
            set {movieCode = value;}
        }
        private string movieName;
        public string MovieName {
            get {return movieName;}
            set {movieName = value;}
        }

        private string movieDescription;
        public string MovieDescription {
            get {return movieDescription;}
            set {movieDescription = value;}
        }
        private string movieDirectorName;
        public string MovieDirectorName {
            get {return movieDirectorName;}
            set {movieDirectorName = value;}
        }

        private int totalNoOfSeats;
        public int TotalNoOfSeats {
            get { return totalNoOfSeats;}
            set { totalNoOfSeats = value;}
        }

        private int seatsOccupied;
        public int SeatsOccupied {
            get { return seatsOccupied;}
            set { seatsOccupied = value;}
        }

        public Movie(string movieCode, string movieName, string movieDescription, string movieDirectorName,  int totalNoOfSeats)
        {
            this.movieCode = movieCode;
            this.movieName = movieName;
            this.movieDescription = movieDescription;
            this.movieDirectorName = movieDirectorName;
            this.totalNoOfSeats = totalNoOfSeats;
            this.seatsOccupied = 0;
        }

        //Constructor call when the movie description is not availabel 
        public Movie(string movieCode,string movieName, string movieDirectorName,  int totalNoOfSeats)
        {
            this.movieCode = movieCode;
            this.movieName = movieName;
            this.movieDescription = "None";
            this.movieDirectorName = movieDirectorName;
            this.totalNoOfSeats = totalNoOfSeats;
            this.seatsOccupied = 0;
        }

        public override string ToString() {
            return $@"
            Movie Name: {this.movieName}
            Description: {this.movieDescription}
            Directors Name: {this.movieDirectorName}
            Total Seats: {this.totalNoOfSeats}
            Available Seats: {this.totalNoOfSeats - this.seatsOccupied}";
        }
    }
}