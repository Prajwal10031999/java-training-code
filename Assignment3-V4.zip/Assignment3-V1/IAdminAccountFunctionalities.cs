namespace TicketBookingApp
{
    /*
        This interface defines all the basic functionalities for admin account.
    */
    public interface IAdminAccountFunctionalities
    {
        public void AddMovie();
        public void RemoveMovie();
        public void DisplayAllUsers();
        public void AddUser();
        public void RemoveUser();
        public void DisplayBookedTickets();
    }
}