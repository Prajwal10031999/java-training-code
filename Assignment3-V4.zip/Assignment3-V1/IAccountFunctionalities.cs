namespace TicketBookingApp
{
    /*
        Defines the required functionalities for any account.
    */
    public interface IAccountFunctionalities
    {
        public void ChangePassword(string newPassword);
    }
}