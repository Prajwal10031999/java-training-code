namespace TicketBookingApp
{
    /*
        This Class has two fields emailId and accountPassword and it extends Account class
        It also implements the IAccountFunctionalities interface
    */
    public class UserAccount : Account, IAccountFunctionalities
    {
        private string emailId;
        public string EmailId {
            get{ return emailId;}
            set{ emailId = value;}
        }

        private string accountPassword;
        public string AccountPassword {
            get { return accountPassword;}
            set { accountPassword = value;}
        }
        public UserAccount(string firstName, string lastName,string emailId, string accountPassword) : base(firstName, lastName)
        {
            this.emailId = emailId;
            this.accountPassword = accountPassword;
        }

        public void ChangePassword(string newPassword)
        {
            this.accountPassword = newPassword;
        }

        public override string? ToString()
        {
            return base.ToString();
        }
    }
}