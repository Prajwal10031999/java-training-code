namespace TicketBookingApp
{
    /*
        This Class has one field adminId and it extends Account class,
        It also implements the IAccountFunctionalities interface
    */
    public class AdminAccount : Account, IAccountFunctionalities
    {
        
        private string adminId;

        private string accountPassword; // string account password
        public string AccountPassword{
            get { return accountPassword;}
            set { accountPassword = value;}
        }

        public AdminAccount(string firstName, string lastName, string adminId, string accountPassword) : base(firstName, lastName)
        {
            this.adminId = adminId;
            this.accountPassword = accountPassword;
        }

        public void ChangePassword(string newPassword)
        {
            this.accountPassword = newPassword;
        }

        public override string? ToString()
        {
            return base.ToString();
        }
    }
}