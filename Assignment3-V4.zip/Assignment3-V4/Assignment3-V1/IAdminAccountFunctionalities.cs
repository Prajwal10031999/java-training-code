namespace TicketBookingApp
{
    /*
        This interface defines all the basic functionalities for admin account.
        These functions will be limited to the admin only.
        Currently we are keeping just a single admin for example purpose.
        But the number can always be increased.
    */
    public interface IAdminAccountFunctionalities
    {
        public void AddMovie();
        public void RemoveMovie();
        public void DisplayAllUsers();
        public void AddUser();
        public void RemoveUser();
        public void DisplayBookedTickets();
    }
}