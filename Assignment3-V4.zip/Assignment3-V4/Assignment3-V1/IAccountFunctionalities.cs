namespace TicketBookingApp
{
    /*
        Defines the required password changing functionality for any account.
    */
    public interface IAccountFunctionalities
    {
        public void ChangePassword(string newPassword);
    }
}