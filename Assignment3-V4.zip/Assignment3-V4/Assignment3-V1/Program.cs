﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

namespace TicketBookingApp
{
    public class MainCLass{
        public static void Main(string[] args) {
            // Movie newMovie = new Movie("movieName", "description", "DirectorName", 10, 5);
            // Ticket newTicket = new Ticket("MOV001", newMovie, 400.00f, 3, "28/08/2022");
            // AdminAccount newAdminAccount = new AdminAccount("AdminName", "LastName", "ADMIN001", "Password");
            // UserAccount newUserAccount = new UserAccount("UserName", "LastName", "Password");
            // GuestAccount newGuestAccount = new GuestAccount("GuestName", "LastName");
            // System.Console.WriteLine(newTicket.ToString());
            TicketBookingCounter newOne = new TicketBookingCounter();
        }
    }
}
