namespace TicketBookingApp
{
    public abstract class Account
    {
        private string firstName; // a  string firstname
        public string FirstName {
            get{ return firstName;}
            set{ firstName = value;}
        }
        private string lastName;  // a string lastname
        public string LastName {
            get{ return lastName;}
            set{ lastName = value;}
        }

        public Account(string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
        }
    }
}