using System;

namespace TicketBookingApp
{
    /*
        TicketBookingCounter is the class that will handle each n every
        operation inside this application.
    */
    public class TicketBookingCounter : IAdminAccountFunctionalities
    {
        Dictionary<string, Movie> movieList;            // This dictionary will store all the movies
        Dictionary<string, Ticket> bookedTickets;       // This dictionary will store all booked tickets
        Dictionary<string, UserAccount> listedUsers;    //This dictionary will store all Registerd Users
        AdminAccount singleAdminAccount;               
        private int uniqueTicketNumber;
        private float basePrice;                        //Base price for every ticket


        public TicketBookingCounter()
        {
            uniqueTicketNumber = 101;
            basePrice = 100;
            movieList = new Dictionary<string, Movie>();
            bookedTickets = new Dictionary<string, Ticket>();
            listedUsers  = new Dictionary<string, UserAccount>();
            singleAdminAccount = new AdminAccount("John", "Wick","WICK007","JOHNWICK");

            PopulateData();
            LogInPage();
        }
        
        //Popullate basic required fields in this app.
        private void PopulateData() {
            /*
            For example purpose we will only put 2 movies in our app for now.
            The system is single admin type and the admin has all the permission.
            Also we will take a sample User for our convinience.
            */
            Movie movieOne = new Movie("ICPN","Inception", "Story of dreams within dreams.", "Nolan", 50);
            Movie movieTwo = new Movie("ISTR","Interstellar","Story of black","Nolan",40);
            movieList.Add(movieOne.MovieCode, movieOne);
            movieList.Add(movieTwo.MovieCode, movieTwo);

            UserAccount user = new UserAccount("Prajwal", "Shegaonkar","prajwalssi@gmail.com", "PS");
            listedUsers.Add(user.EmailId, user);

            Ticket ticket = new Ticket("TGN001",movieOne,300, SeatType.PLATINUM,2,"12/01/22");
            bookedTickets.Add(ticket.TicketNumber, ticket);
        }

        //Displays welcome message and asks for the user Type
        private void LogInPage() {
            Console.WriteLine("Welcome to ***PVR***",50);
            EnteredInvalidInput:
            Console.WriteLine("Enter your role :  \n 1.Admin\n 2.RegisteredUser\n 3.GuestUser");
            int userChoice  = Convert.ToInt32(Console.ReadLine());
            switch (userChoice)
            {
                case 1: AdminLogInPage();
                        break;
                case 2: UserLogInPage();
                        break;
                case 3: GuestLogInPage();
                        break;
                default:
                    Console.WriteLine("Please Enter A Valid Choice");
                    goto EnteredInvalidInput;
            }
        }

        public void AdminLogInPage() {
            RetryPassword:
            Console.WriteLine("Hello Admin \nEnter password");
            string enteredPassword = Console.ReadLine() ?? "";
            if(enteredPassword == singleAdminAccount.AccountPassword) {
                Console.WriteLine("Successfully Logged In as Admin..");
                Console.WriteLine("Enter no. in front");
                EnteredInvalidInput:
                Console.WriteLine("1.To perform basic user funcitons\n2.To perform admin functions");
                int userChoice = Convert.ToInt32(Console.ReadLine());
                switch (userChoice)
                {
                    case 1: RegisteredUserFunctionalities();
                            break;
                    case 2: AdminAccountFunctionalities();
                            break;
                    default:
                        Console.WriteLine("Please Enter vaid Input.");
                        goto EnteredInvalidInput;
                }
            } else {
                Console.WriteLine("Something went wrong please try again");
                Console.WriteLine("Press 1 to Change Password and any other key to retry");
                    int userChoicePassword = Convert.ToInt32(Console.ReadLine()??"0");
                    if(userChoicePassword == 1) {
                        Console.WriteLine("Enter new Password");
                        string newPassword = Console.ReadLine() ?? "";
                        singleAdminAccount.ChangePassword(newPassword);
                    } else {
                        goto RetryPassword;
                    }
            }
        }

        public void UserLogInPage() {
            Console.WriteLine("Hello Mr. User \n Enter registered emailId");
            string enteredEmailId = Console.ReadLine() ?? "";
            RetryPassword:
            Console.WriteLine(" Enter password");
            string enteredPassword = Console.ReadLine() ?? "";
            if(listedUsers.ContainsKey(enteredEmailId)) {
                UserAccount fetchedAccount = listedUsers[enteredEmailId];
                if(enteredPassword == fetchedAccount.AccountPassword) {
                    Console.WriteLine($"Successfully Logged In as {fetchedAccount.FirstName}");
                    RegisteredUserFunctionalities();
                } else {
                    Console.WriteLine("Entered password is invalid");
                    Console.WriteLine("Press 1 to Change Password and any other key to retry");
                    int userChoicePassword = Convert.ToInt32(Console.ReadLine()??"0");
                    if(userChoicePassword == 1) {
                        Console.WriteLine("Enter new Password");
                        string newPassword = Console.ReadLine() ?? "";
                        fetchedAccount.ChangePassword(newPassword);
                    } else {
                        goto RetryPassword;
                    }
                }
            } else {
                Console.WriteLine("Entered emailId or password is invalid");
            }
        }

        
        public void GuestLogInPage() {
            Console.WriteLine("Hello Guest");
            GuestFunctionalities();
        }

        //Takes a choice from user and execute corresponding the guest funtions
        public void GuestFunctionalities() {
            EnteredInvalidInput:
            Console.WriteLine("\nEnter the function to be performed : \n 1.Check Available shows 2.Exit");
            int userChoice = Convert.ToInt32(Console.ReadLine());
            switch (userChoice)
            {
                case 1: CheckAvailabilityOfShows();
                        break;
                case 2: return;
                default:
                    Console.WriteLine("Please Enter A valid Input.");
                    goto EnteredInvalidInput;
            }

        }

        //Takes a choice from user and execute corresponding the registered user funtions
         public void RegisteredUserFunctionalities() {  
            EnteredInvalidInput:
            Console.WriteLine("\nEnter your choice to : \n1.Check Available shows 2.Book Ticket 3.Cancel Ticket 4.View Ticket 5.View Movie Details 6.Exit");
            int userChoice = Convert.ToInt32(Console.ReadLine());
            switch (userChoice)
            {
                case 1: CheckAvailabilityOfShows();
                        goto EnteredInvalidInput;
                case 2: BookTicket();
                        goto EnteredInvalidInput;
                case 3: CancelTicket();
                        goto EnteredInvalidInput;
                case 4: ViewTicket();
                        goto EnteredInvalidInput;
                case 5: ShowMovieDetails();
                        goto EnteredInvalidInput;
                case 6: return;
                default:
                    Console.WriteLine("Please Enter valid Input.");
                    goto EnteredInvalidInput;
            }
        }

        //Takes a choice from user and execute corresponding the admin funtions
        public void AdminAccountFunctionalities() {
            EnteredInvalidInput:
            Console.WriteLine("\nEnter the choice : \n1.Add User  2.Remove User 3.Add Movie 4.Remove Movie 5.Display all tickets 6.Display all Users 7.Exit ");
            int userChoice = Convert.ToInt32(Console.ReadLine());
            switch (userChoice)
            {
                case 1: AddUser();
                        goto EnteredInvalidInput;
                case 2: RemoveUser();
                        goto EnteredInvalidInput;
                case 3: AddMovie();
                        goto EnteredInvalidInput;
                case 4: RemoveMovie();
                        goto EnteredInvalidInput;
                case 5: DisplayBookedTickets();
                        goto EnteredInvalidInput;
                case 6: DisplayAllUsers();
                        goto EnteredInvalidInput;
                case 7: return;
                default:
                    Console.WriteLine("Please Enter vaid Input.");
                    goto EnteredInvalidInput;
            }

        }


        //Displays all the movies present in movieList
        public void CheckAvailabilityOfShows() {
            int index = 1;
            Console.WriteLine($"{"Sr.",-5} {"Movie Code",-30} {"Movie Name",-30} {"Seats Aval:",-30}");

            foreach(Movie instantMovie in movieList.Values) {
                Console.WriteLine($"{index,-7}{instantMovie.MovieCode,-30}{instantMovie.MovieName,-30} {instantMovie.TotalNoOfSeats - instantMovie.SeatsOccupied, -30} ");
                index++;
            }
        }

        //Takes the required inputs to create a ticket and adds it to the booked ticket dictionary.
        public void BookTicket() {
            Console.WriteLine("\nEnter the Movie Code to book ticket for movie..\n");
            CheckAvailabilityOfShows();
            string userChoice = Console.ReadLine() ?? "";
            if(movieList.ContainsKey(userChoice)) {
                Movie selectedMovie = movieList[userChoice];
                Console.WriteLine("Enter No. of Seats to book :");
                int noOfSeats = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter SEAT TYPE \n1.SILVER 2.GOLD 3.PLATINUM");
                int seatTypeChoice = Convert.ToInt32(Console.ReadLine());
                SeatType enteredSeatType;
                float ticketPrice;
                switch (seatTypeChoice)
                {
                    case 1: enteredSeatType = SeatType.SILVER;
                        ticketPrice = basePrice * 1;
                        break;
                    case 2: enteredSeatType = SeatType.GOLD;
                        ticketPrice = basePrice * 2;
                        break;
                    case 3: enteredSeatType = SeatType.PLATINUM;
                        ticketPrice = basePrice * 3;
                        break;
                    default:
                        enteredSeatType = SeatType.SILVER;
                        ticketPrice = basePrice * 1;
                        break;
                }
                uniqueTicketNumber++;
                Ticket newTicket = new Ticket(selectedMovie.MovieCode+uniqueTicketNumber.ToString(), selectedMovie, ticketPrice, enteredSeatType, noOfSeats, "13/06/22"); //Hard coded date, Can take real time date 
                bookedTickets.Add(newTicket.TicketNumber, newTicket);
                movieList[userChoice].SeatsOccupied += noOfSeats;
                Console.WriteLine(newTicket.ToString());
                Console.WriteLine($"Pay {ticketPrice} on Counter \nSuccessfully booked your tickets...!!!");
            } else {
                Console.WriteLine("Enter A Valid Code For Movie Of Your Choice:");
            }
        }

        //Takes ticket number as an input and removes the correspoding ticket from booked tickets dictionary.
        public void CancelTicket() {
            Console.WriteLine("Enter the Ticket Number");
            string enteredTicketNumber = Console.ReadLine() ?? "";
            if(bookedTickets.ContainsKey(enteredTicketNumber)) {
                bookedTickets.Remove(enteredTicketNumber);
                Console.WriteLine("Ticket Cancelled Successfully..!!\nMoney will be refuned in next 7-8 working days");
            } else {
                Console.WriteLine("No ticket exit.");
            }
        }

        //Takes ticket number as an input and display the corresponding ticket details. 
        public void ViewTicket() {
            Console.WriteLine("Enter the Ticket Number");
            string enteredTicketNumber = Console.ReadLine() ?? "";
            if(bookedTickets.ContainsKey(enteredTicketNumber)) {
                Console.WriteLine("Ticket Details:");
                Console.WriteLine(bookedTickets[enteredTicketNumber].ToString());
            } else {
                Console.WriteLine("No ticket exit.");
            }
        }

        //Takes movie code as input ad displays the details of the corresponding movie.
        public void ShowMovieDetails() {
            Console.WriteLine("\nEnter the Movie Code to view for movie details..\n");
            CheckAvailabilityOfShows();
            InvalidInput:
            string userChoice = Console.ReadLine() ?? "";
            if(movieList.ContainsKey(userChoice)) {
                Console.WriteLine(movieList[userChoice].ToString());
            } else {
                Console.WriteLine("Enter Valid Movie Code");
                goto InvalidInput;
            }

        }

        /*
        Implement the AdminAccountfunctionalities Interface
        */

        //Takes all the inputs that are  required to create UserAccount and 
        //add it to the listedUser dictionary
        public void AddUser() {
            Console.WriteLine("Enter New User details in following format"); 
            InvalidInput:
            Console.WriteLine(" <firstName> <lastName> <emailId> <password>");
            var enteredInputs = (Console.ReadLine() ?? "").Split(" ");
            if(enteredInputs.Length == 4){
                UserAccount newUser = new UserAccount(enteredInputs[0], enteredInputs[1], enteredInputs[2], enteredInputs[3]);
                listedUsers.Add(newUser.EmailId, newUser);
            } else {
                Console.WriteLine("!!Invalid format, Enter details in given format!!");
                goto InvalidInput;
            }
        }

        //Takes user email as input and remove the corresponding User from listed user dictionary 
        public void RemoveUser() {
            Console.WriteLine("\nEnter the email id of the user to be removed ..");
            string enteredEmailId = Console.ReadLine() ?? "";
            if(listedUsers.ContainsKey(enteredEmailId)) {
                listedUsers.Remove(enteredEmailId);
                Console.WriteLine("Successfully removed the user");
            } else {
                Console.WriteLine("No such User exists");
            }
        }


        //Takes all the input required to create Movie object and adds it to the movieList
        public void AddMovie() {
            Console.WriteLine("Enter the following details to add a movie:"); 
            Console.Write("Enter Movie Code: ");
            string entredMovieCode = Console.ReadLine() ?? "";
            Console.Write("Movie Name: ");
            string enteredMovieName = Console.ReadLine() ?? "";
            Console.Write("Movie Description: ");
            string enteredMovieDescription = Console.ReadLine() ?? "";
            Console.Write("Movie Director Name: ");
            string enteredDirectorName = Console.ReadLine() ?? "";
            Console.Write("Total no. of seats: ");
            int enteredNoOfSeats = Convert.ToInt32(Console.ReadLine());

            Movie newMovie = new Movie(entredMovieCode,enteredMovieName, enteredMovieDescription, enteredDirectorName, enteredNoOfSeats);
            movieList.Add(newMovie.MovieCode, newMovie);
            Console.WriteLine("Successfully added the movie");
        }
        

        //Take movie code as input and removes the correspoding movie from dictionary
        public void RemoveMovie() {
            Console.WriteLine("\nEnter the movie code of the movie to be removed ..");
            string enteredMovieCode = Console.ReadLine() ?? "";
            if(movieList.ContainsKey(enteredMovieCode)) {
                movieList.Remove(enteredMovieCode);
                Console.WriteLine("Successfully removed the movie");
            } else {
                Console.WriteLine("No such Movie exists");
            }
        }

        //Displays all the tickets booked till date
        public void DisplayBookedTickets() {
            int index = 1;
            Console.WriteLine($"{"Sr.",-5} {"Ticket No.",-30} {"Movie Name",-30} {"Price",-10} {"No. of Seats",-10} {"Date",-10}");
            foreach(Ticket instantTicket in bookedTickets.Values) {
                Console.WriteLine($"{index,-7}" + instantTicket.ToSingleString());
                index++;
            }
        }

        //Displays all the users stored in the code.
        public void DisplayAllUsers() {
            int index = 1;
            Console.WriteLine($"{"Sr.",-5} {"First Name",-30} {"Last Name",-30} {"Email Id",-30}");
            foreach(UserAccount instantUser in listedUsers.Values) {
                Console.WriteLine($"{index,-7}{instantUser.FirstName,-30}{instantUser.LastName, -30}{instantUser.EmailId,-30}" );
                index++;
            }
        }

    }
}